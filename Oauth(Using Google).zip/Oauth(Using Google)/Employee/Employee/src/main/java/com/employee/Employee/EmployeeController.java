package com.employee.Employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private DiscoveryClient discoveryClient;

	@GetMapping("/display")
	public String name() {
		return "aaryan";
	}

	@PostMapping("/message")
	public String postMessage(@RequestParam("message") String message) {
		return "Received message: " + message;
	}

	@PostMapping("/send")
	public ResponseEntity<String> sendMessage(@RequestBody Employee employee) {
		List<ServiceInstance> instances = discoveryClient.getInstances("Receiver");
		if (instances.isEmpty()) {
			return new ResponseEntity<>("Receiver service not found", HttpStatus.SERVICE_UNAVAILABLE);
		}

		ServiceInstance receiverInstance = instances.get(0);
		String url = receiverInstance.getUri().toString() + "/receiver/receive";
		ResponseEntity<String> response = null;
		try {

			response = restTemplate.postForEntity(url, employee, String.class);
			System.out.println("Response " + response);
			return new ResponseEntity<>("Employee sent successfully: " + employee, HttpStatus.OK);
		} catch (Exception e) {
			System.out.println("Exception" + e.getMessage());
			return new ResponseEntity<>("Error occurred while sending employee: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
