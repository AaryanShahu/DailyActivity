package com.receiver.Receiver;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/receiver")
public class ReceiverController {
	private Employee receivedMessage;

	@PostMapping("/receive")
	public ResponseEntity<String> receiveMessage(@RequestBody Employee employee) {
		try {

			if (employee.getId().equals("") || employee.getName().equals("") || employee.getCity().equals("")) {
				throw new RuntimeException("Invalid employee details");
			}

			this.receivedMessage = employee;
			return new ResponseEntity<>("Received message: " + employee, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>("Failed to receive message: " + e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/display")
	public Employee displayMessage() {
		return receivedMessage != null ? receivedMessage : new Employee("No ID", "No Name", "No City");
	}
}
