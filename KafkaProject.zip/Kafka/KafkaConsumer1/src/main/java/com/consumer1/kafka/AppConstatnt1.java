package com.consumer1.kafka;

public class AppConstatnt1 {

 //   public static final String LOCATION_UPDATE_TOPIC="location-update-topic";
    public static final String  GROUP_ID="group-2";
	public static final String ORDER_UPDATE_TOPIC = "order-update-topic";

}
