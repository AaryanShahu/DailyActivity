package com.consumer1.kafka;




import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

@Configuration
public class KafkaConfig1 {


   
    		@KafkaListener(topics = AppConstatnt1.ORDER_UPDATE_TOPIC, groupId = AppConstatnt1.GROUP_ID)
    		public void updatedLocation(String value) {


        System.out.println("Consumer 2 received" +value);

    }

}
