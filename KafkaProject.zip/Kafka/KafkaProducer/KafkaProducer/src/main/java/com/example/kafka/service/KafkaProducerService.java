package com.example.kafka.service;

import com.example.kafka.config.AppConstants;

import java.util.List;
import java.util.concurrent.Future;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaProducerService {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

  
    
    private Logger logger = LoggerFactory.getLogger(KafkaProducerService.class);

    public boolean updateLocation(String location) {
        return sendMessage(AppConstants.LOCATION_UPDATE_TOPIC, location);
    }

    public boolean updateOrder(String order) {
        return sendMessage(AppConstants.ORDER_UPDATE_TOPIC, order);
    }

    /* USING EUREKA
    private boolean sendMessage(String topic, String message) {
        try {
              List<ServiceInstance> instances = discoveryClient.getInstances("kafka-consumer");
            if (instances != null && !instances.isEmpty()) {
                // Implement your logic here to send the message to the discovered instance
                kafkaTemplate.send(topic, message);
                logger.info("Message sent to topic {}: {}", topic, message);
                return true;
            } else {
                logger.warn("No Kafka Consumers available to send message to topic {}: {}", topic, message);
                return false;
            }
        } catch (Exception e) {
            logger.error("Failed to send message to topic {}: {}", topic, message, e);
            return false;
        }
    }
    
    */
    private boolean sendMessage(String topic, String message) {
        try {
            kafkaTemplate.send(topic, message);
            logger.info("Message sent to topic {}: {}", topic, message);
            return true;
        } catch (Exception e) {
            logger.error("Failed to send message to topic {}: {}", topic, message, e);
            return false;
        }
    }
       
    
    
    

    public boolean updateLocationToSpecificPartition(String location, int partition) {
        return sendToSpecificPartition(AppConstants.LOCATION_UPDATE_TOPIC, location, partition);
    }

    public boolean updateOrderToSpecificPartition(String order, int partition) {
        return sendToSpecificPartition(AppConstants.ORDER_UPDATE_TOPIC, order, partition);
    }
    
    
    
//    
//    public boolean sendToSpecificPartition(String topic, String message, int partition) {
//        try {
//            Future<RecordMetadata> future = kafkaTemplate.send(topic, partition, null, message);
//            RecordMetadata metadata = future.get();
//            logger.info("Message sent to topic {} partition {}: {}, offset: {}", topic, partition, message, metadata.offset());
//            return true;
//        } catch (InterruptedException | ExecutionException e) {
//            logger.error("Failed to send message to topic {} partition {}: {}", topic, partition, message, e);
//            return false;
//        }
//    }
//    
//    
    public boolean sendToSpecificPartition(String topic, String message, int partition) {
            try {
                kafkaTemplate.send(topic, partition, null, message);
                logger.info("Message sent to topic {} partition {}: {}", topic, partition, message);
                return true;
            } catch (Exception e) {
                logger.error("Failed to send message to topic {} partition {}: {}", topic, partition, message, e);
                return false;
            }
    }
}

//package com.example.kafka.service;
//
//import com.example.kafka.config.AppConstants;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.stereotype.Service;
//
//@Service
//public class KafkaProducerService {
//
//    @Autowired
//    private KafkaTemplate<String, String> kafkaTemplate;
//
//    private Logger logger = LoggerFactory.getLogger(KafkaProducerService.class);
//
//    public boolean updateLocation(String location) {
//
//        this.kafkaTemplate.send(AppConstants.LOCATION_TOPIC_NAME, location);
//
//        return true;
//    }
//
//}
//	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	public void sendMessage(String message) {
        CompletableFuture<SendResult<String, Object>> future = template.send(
            MessageBuilder.withPayload(message)
                .setHeader(KafkaHeaders.TOPIC, "first-topic")
                .setHeader("messageType", "string")
                .build()
        );
        
        future.whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println(result.getRecordMetadata().partition());
                System.out.println(result.getRecordMetadata().offset());
                System.out.println("Message sent by producer to consumer is: " + message);
            } else {
                System.out.println(ex.getMessage());
            }
        });
    }

    public void sendObject(Customer customer) {
        CompletableFuture<SendResult<String, Object>> future = template.send(
            MessageBuilder.withPayload(customer)
                .setHeader(KafkaHeaders.TOPIC, "first-topic")
                .setHeader("messageType", "customer")
                .build()
        );
        
        future.whenComplete((result, ex) -> {
            if (ex == null) {
                System.out.println(result.getRecordMetadata().partition());
                System.out.println(result.getRecordMetadata().offset());
                System.out.println("Message sent by producer to consumer is: " + customer.toString());
            } else {
                System.out.println(ex.getMessage());
            }
        });
}    }
	*/




