package com.example.kafka.model;

import lombok.Data;

@Data
public class Customer {
	
	private int id;
	private String name;

}
