package com.example.kafka.controller;

import com.example.kafka.service.KafkaProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/kafka")
public class KafkaProducerController {

    @Autowired
    private KafkaProducerService kafkaService;

    @PostMapping("/location/update")
    public ResponseEntity<?> updateLocation() {
        for (int i = 1; i <= 20; i++) {
            String location = "( " + Math.round(Math.random() * 100) + " , " + Math.round(Math.random() * 100) + " )";
            kafkaService.updateLocation(location);
        }
        return new ResponseEntity<>(Map.of("message", "Location updated"), HttpStatus.OK);
    }

    @PostMapping("/order/update")
    public ResponseEntity<?> updateOrder() {
        for (int i = 1; i <= 20; i++) {
            String order = "Order " + i + " : Item" + Math.round(Math.random() * 100);
            kafkaService.updateOrder(order);
        }
        return new ResponseEntity<>(Map.of("message", "Order updated"), HttpStatus.OK);
    }

@PostMapping("/location/updatePartition")
public ResponseEntity<?> updateLocationToSpecificPartition() {
    for (int i = 1; i <= 20; i++) {
        String location = "location :( " + Math.round(Math.random() * 100) + " , " + Math.round(Math.random() * 100) + " )";
        int partition=i%3;
        kafkaService.updateLocationToSpecificPartition(location, partition);
    }
    return new ResponseEntity<>(Map.of("message", "Location updated to specific partition"), HttpStatus.OK);
}

@PostMapping("/order/updatePartition")
public ResponseEntity<?> updateOrderToSpecificPartition() {
    for (int i = 1; i <= 20; i++) {
        String order = "Order " + i + " : Item" + Math.round(Math.random() * 100);
        int partition=i%3;
        kafkaService.updateOrderToSpecificPartition(order, partition);
    }
    return new ResponseEntity<>(Map.of("message", "Order updated to specific partition"), HttpStatus.OK);
}
}
//package com.example.kafka.controller;
//
//import com.example.kafka.service.KafkaProducerService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.Map;
//
//@RestController
//@RequestMapping("/location")
//public class KafkaProducerController {
//
//    @Autowired
//    private KafkaProducerService kafkaService;
//
//    @PostMapping("/update")
//    public ResponseEntity<?> updateLocation() {
//
//        for (int i = 1; i <= 20; i++) {
//            this.kafkaService.updateLocation("( " + Math.round(Math.random() * 100) + " , " + Math.round(Math.random() * 100) + " " + ")");
//        }
//
//        return new ResponseEntity<>(Map.of("message", "Location updated"), HttpStatus.OK);
//    }
//
//}