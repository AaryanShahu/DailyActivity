package com.example.kafka.config;

public class AppConstants {
    public static final String LOCATION_UPDATE_TOPIC = "location-update-topic";
    public static final String ORDER_UPDATE_TOPIC = "order-update-topic";
 
}

//package com.example.kafka.config;
//
//public class AppConstants {
//    public static final String LOCATION_TOPIC_NAME = "location-update-topic";
//}
