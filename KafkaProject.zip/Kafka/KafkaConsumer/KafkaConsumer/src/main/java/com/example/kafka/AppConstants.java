package com.example.kafka;

public class AppConstants {

    public static final String LOCATION_UPDATE_TOPIC="location-update-topic";
    public static final String  GROUP_ID="group-1";
	//public static final String ORDER_UPDATE_TOPIC = "order-update-topic";

}