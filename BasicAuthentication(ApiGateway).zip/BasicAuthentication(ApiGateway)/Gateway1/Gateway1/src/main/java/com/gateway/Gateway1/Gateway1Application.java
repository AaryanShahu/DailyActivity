package com.gateway.Gateway1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@SpringBootApplication
@EnableEurekaClient
public class Gateway1Application {

    private static final Logger logger = LoggerFactory.getLogger(Gateway1Application.class);

    public static void main(String[] args) {
        logger.info("Starting Gateway1Application...");
        SpringApplication.run(Gateway1Application.class, args);
        logger.info("Gateway1Application started successfully.");
    }

}
