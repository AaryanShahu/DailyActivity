package com.faculty.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.faculty.model.Faculty;
import com.faculty.service.FacultyService;

@RestController
@RequestMapping("/faculty")
public class FacultyController {

    @Autowired
    private FacultyService facultyService;

    @PostMapping("/create")
    public String createFaculty(@RequestBody Faculty faculty) {
        facultyService.saveFaculty(faculty);
        return "Faculty saved successfully";
    }

    @PostMapping("/rollback")
    public String rollbackFaculty(@RequestBody Faculty faculty) {
        facultyService.deleteFaculty(faculty.getId());
        return "Faculty rollback successful";
    }
}
