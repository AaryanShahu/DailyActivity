package com.faculty.application;

import org.apache.ibatis.type.MappedTypes;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.faculty.mapper.FacultyMapper;

@MappedTypes(FacultyMapper.class)
@MapperScan("com.faculty.mapper")
@SpringBootApplication
@ComponentScan(basePackages = "com.faculty") 
@EnableTransactionManagement
public class FacultyApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacultyApplication.class, args);
	}

}
