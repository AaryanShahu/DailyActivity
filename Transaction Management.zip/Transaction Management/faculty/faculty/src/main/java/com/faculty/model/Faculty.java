package com.faculty.model;

public class Faculty {
	 private int id;
	    private String faculty_name;
	    private String department;
	    public Faculty() {
	    	
	    }
		public Faculty(int id, String faculty_name, String department) {
			super();
			this.id = id;
			this.faculty_name = faculty_name;
			this.department = department;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getFaculty_name() {
			return faculty_name;
		}
		public void setFaculty_name(String faculty_name) {
			this.faculty_name = faculty_name;
		}
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			this.department = department;
		}
}
