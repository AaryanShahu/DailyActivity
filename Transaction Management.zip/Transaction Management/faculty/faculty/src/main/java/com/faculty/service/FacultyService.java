package com.faculty.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.faculty.mapper.FacultyMapper;
import com.faculty.model.Faculty;
@Service
public class FacultyService {

    @Autowired
    private FacultyMapper facultyRepository;
   @Transactional
    public void saveFaculty(Faculty faculty) {
        facultyRepository.insert(faculty);
    }

    public void deleteFaculty(int id) {
        facultyRepository.delete(id);
    }
}
