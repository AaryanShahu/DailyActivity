package com.faculty.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import com.faculty.model.Faculty;

@Mapper
public interface FacultyMapper {

    @Insert("INSERT INTO faculty(id, faculty_name, department) VALUES(#{id}, #{faculty_name}, #{department})")
    void insert(Faculty faculty);

    @Delete("DELETE FROM faculty WHERE id = #{id}")
    void delete(int id);
}
