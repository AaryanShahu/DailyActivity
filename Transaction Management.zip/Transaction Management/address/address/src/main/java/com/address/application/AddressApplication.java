package com.address.application;

import org.apache.ibatis.type.MappedTypes;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.address.mapper.AddressMapper;


@MappedTypes(AddressMapper.class)
@MapperScan("com.address.mapper")
@SpringBootApplication
@ComponentScan(basePackages = "com.address") 
@EnableTransactionManagement
public class AddressApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddressApplication.class, args);
	}

}
