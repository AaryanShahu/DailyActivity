package com.address.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import com.address.model.Address;

@Mapper
public interface AddressMapper {
 
 @Insert("INSERT INTO address (id, city, state) VALUES (#{id}, #{city}, #{state})")
 void insert(Address address);

 @Delete("DELETE FROM address WHERE id = #{id}")
 void deleteId(int studentId);
}
