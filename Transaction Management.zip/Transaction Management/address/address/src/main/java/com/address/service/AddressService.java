package com.address.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.address.mapper.AddressMapper;
import com.address.model.Address;

@Service
public class AddressService {

 @Autowired
 private AddressMapper repo;

 @Transactional
 public void addAddress(Address address) {
     repo.insert(address);
 }

 @Transactional
 public void deleteAddress(int id) {
     repo.deleteId(id);
 }
}
