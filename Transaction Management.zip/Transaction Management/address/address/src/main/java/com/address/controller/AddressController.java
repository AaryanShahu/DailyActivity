package com.address.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.address.model.Address;
import com.address.service.AddressService;

@RestController
@RequestMapping("/address")
public class AddressController {
    @Autowired
    private AddressService addressService;

    @PostMapping("/add")
    public String addAddress(@RequestBody Address address) {
        addressService.addAddress(address);
        return "Address Added!";
    }

    @PostMapping("/rollback")
    public String rollbackAddress(@RequestBody Address address) {
        addressService.deleteAddress(address.getId());
        return "Address Rolled Back!";
    }
}
