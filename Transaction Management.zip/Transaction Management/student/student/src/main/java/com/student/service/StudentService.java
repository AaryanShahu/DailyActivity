package com.student.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.student.mapper.StudentMapper;
import com.student.model.Student;
import com.faculty.model.*;
@Service
public class StudentService {

    @Autowired
    private StudentMapper studentRepository;

    @Autowired
    private RestTemplate restTemplate;

    @Transactional
    public void saveStudent(Student student) {
       
        
studentRepository.insert(student);
//        try {
//        	studentRepository.insert(student);
//            restTemplate.postForObject("http://localhost:1002/address/add", student.getAddress(), String.class);
//            restTemplate.postForObject("http://localhost:1003/faculty/create", student.getFaculty(), String.class);         
//        } catch (Exception e) {
//            studentRepository.delete(student.getId());
//            restTemplate.postForObject("http://localhost:1002/address/rollback", student.getAddress(),String.class);
//            restTemplate.postForObject("http://localhost:1003/faculty/rollback", student.getFaculty(), String.class);
//            throw new RuntimeException("Failed to create address, rolling back student creation");
//        }

//        try {
//            restTemplate.postForObject("http://localhost:1003/faculty/create", student.getFaculty(), String.class);
//        } catch (Exception e) {
//            studentRepository.delete(student.getId());
//            restTemplate.delete("http://localhost:1002/address/rollback/" + student.getAddress().getId());
//
//            throw new RuntimeException("Failed to create faculty, rolling back student and address creation");
//        }
    }

    public void deleteStudent(int id) {
        studentRepository.delete(id);
    }
}























//@Service
//public class StudentService {
//
// @Autowired
// private StudentMapper repo;
//
// @Transactional
// public void addStudent(Student student) {
//     repo.insert(student);
// }
//
// @Transactional
// public void deleteStudent(int studentId) {
//     repo.delete(studentId);
// }
//}
