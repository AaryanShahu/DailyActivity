package com.student.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import com.student.model.Student;


@Mapper
public interface StudentMapper {
 

 @Insert("insert into student(id,name, age, classStandard) values(#{id},#{name}, #{age}, #{classStandard})")
 void insert(Student student);

 @Delete("DELETE FROM student WHERE id = #{id}")
 void delete(int id);
}
