package com.student.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.model.Student;
import com.student.service.StudentService;

@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping("/create")
    public String createStudent(@RequestBody Student student) {
        studentService.saveStudent(student);
        return "Student created successfully!";
    }

    @DeleteMapping("/delete/{id}")
    public String deleteStudent(@PathVariable int id) {
        studentService.deleteStudent(id);
        return "Student deleted successfully!";
    }
}





































//@RestController
//@RequestMapping("/student")
//public class StudentController {
//    @Autowired
//    private StudentService studentService;
//
//    @PostMapping("/add")
//    public String addStudent(@RequestBody Student student) {
//        studentService.addStudent(student);
//        return "Student Added!";
//    }
//
//    @PostMapping("/rollback")
//    public String rollbackStudent(@RequestBody int id) {
//        studentService.deleteStudent(id);
//        return "Student Rolled Back!";
//    }
//}
/*
    @Autowired
    private AddressClient addressClient; 
    @Autowired
    private FacultyClient facultyClient;

    @PostMapping("/add")
    public ResponseEntity<String> addStudent(@RequestBody Student student) {
        try {
            studentService.addStudent(student);

            Address address = new Address(student.getId(), "City", "State");
            addressClient.addAddress(address);

            Faculty faculty = new Faculty("Faculty Name", "Department");
            facultyClient.addFaculty(faculty);

            return ResponseEntity.ok("Transaction successful");
        } catch (Exception e) {
            studentService.rollbackStudent(student.getId());
            addressClient.rollbackAddress(student.getId());
            facultyClient.rollbackFaculty(student.getId());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Transaction failed and rolled back");
        }
    }
}
*/
