package com.orchester.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.orchester.service.SagaService;
import com.student.model.Student;


@RestController
@RequestMapping("/orchestrator")
public class SagaController {

    @Autowired
    private SagaService sagaOrchestratorService;

    @PostMapping("/createStudentSaga")
    public String createStudentSaga(@RequestBody Student student) {
        try {
          
            sagaOrchestratorService.createStudentWithAddressAndFaculty(student);
            return "Student, Address, and Faculty created successfully!";
        } catch (Exception e) {
               return "Failed to create student, address, and faculty: " + e.getMessage();
        }
    }
}
