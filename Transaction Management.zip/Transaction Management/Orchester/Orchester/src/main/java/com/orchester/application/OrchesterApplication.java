package com.orchester.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;

@ComponentScan(basePackages = "com.orchester") 
@SpringBootApplication
@EnableTransactionManagement
public class OrchesterApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrchesterApplication.class, args);
	}
	
//	
//	@Bean
//	public RestTemplate restTemplate(){
//		return new RestTemplate();
//	}

}
