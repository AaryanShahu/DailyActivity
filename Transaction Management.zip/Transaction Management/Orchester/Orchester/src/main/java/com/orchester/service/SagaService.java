package com.orchester.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;
import com.student.model.Student;
import reactor.core.publisher.Mono;

@Service
public class SagaService {

    @Autowired
    private WebClient.Builder webClientBuilder;  
    @Transactional
    public void createStudentWithAddressAndFaculty(Student student) {
        try {
            Mono<String> studentResponse = webClientBuilder.build()
                    .post()
                    .uri("http://localhost:1001/student/create")
                    .bodyValue(student)
                    .retrieve()
                    .bodyToMono(String.class);
            
            Mono<String> addressResponse = webClientBuilder.build()
                    .post()
                    .uri("http://localhost:1002/address/add")
                    .bodyValue(student.getAddress())
                    .retrieve()
                    .bodyToMono(String.class);

            Mono<String> facultyResponse = webClientBuilder.build()
                    .post()
                    .uri("http://localhost:1003/faculty/create")
                    .bodyValue(student.getFaculty())
                    .retrieve()
                    .bodyToMono(String.class);

            studentResponse.block();
            addressResponse.block();
            facultyResponse.block();

        } catch (Exception e) {
            rollbackStudent(student);
            throw new RuntimeException("Saga failed, rolling back student, address, and faculty creation.", e);
        }
    }

    @Transactional
    private void rollbackStudent(Student student) {
        try {
            webClientBuilder.build()
                    .delete()
                    .uri("http://localhost:1001/student/delete/" + student.getId())
                    .retrieve()
                    .bodyToMono(Void.class)
                    .block();

            webClientBuilder.build()
                    .post()
                    .uri("http://localhost:1002/address/rollback")
                    .bodyValue(student.getAddress())
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            webClientBuilder.build()
                    .post()
                    .uri("http://localhost:1003/faculty/rollback")
                    .bodyValue(student.getFaculty())
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

        } catch (Exception e) {
            System.out.println("Rollback failed.");
        }
    }
}
