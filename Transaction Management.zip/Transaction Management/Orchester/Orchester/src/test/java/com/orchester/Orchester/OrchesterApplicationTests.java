package com.orchester.Orchester;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrchesterApplicationTests {

	@Test
	void contextLoads() {
	}

}
