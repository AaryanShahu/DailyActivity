package com.oktaproject1.okta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OktaApplicationTests {

	@Test
	void contextLoads() {
	}

}
