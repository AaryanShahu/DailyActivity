package com.oktaproject1.okta;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/one")
public class Controller {

	@GetMapping("/user")
	public String name() {
		return "Aaryan";
	}

    @PostMapping("/message")
    public String postMessage(@RequestBody String message) {
        return "Received message: " + message;
    }
}
