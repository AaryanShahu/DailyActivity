package com.service1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/a")
public class ServiceAController {

    @Autowired
    private RestTemplate restTemplate;
  @GetMapping("/display")
  public String display() {
	  return "hello";
  }
//  public ResponseEntity<String> sendMessage(@RequestBody String name) {
//      String url = "http://localhost:8086/b/receiveMessage"; 
//      try {
//          ResponseEntity<String> response = restTemplate.postForEntity(url, name, String.class);
//          return new ResponseEntity<>("Service A received response: " + response.getBody(), HttpStatus.OK);
//      } catch (Exception e) {
//          System.out.println("Exception while calling Service B: " + e.getMessage());
//          return new ResponseEntity<>("Error occurred while calling Service B: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
//      }
//  }
   

   
}

//@PostMapping("/send")
//public ResponseEntity<String> sendMessage(@RequestBody String name) {
//    String url = "http://localhost:8086/b/receive?name=" + name; // Updated URL to use GET
//    ResponseEntity<String> response;
//    try {
//        response = restTemplate.getForEntity(url, String.class); // Using GET request
//        System.out.println("Response: " + response);
//        return new ResponseEntity<>("Employee sent successfully: " + name, HttpStatus.OK);
//    } catch (Exception e) {
//        System.out.println("Exception: " + e.getMessage());
//        return new ResponseEntity<>("Error occurred while sending employee: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
//    }
//}

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
//import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.client.RestTemplate;
//
//@RestController
//@RequestMapping("/a")
//public class ServiceAController {
//
//    private final RestTemplate restTemplate;
//
//    @Autowired
//    public ServiceAController(RestTemplate restTemplate) {
//        this.restTemplate = restTemplate;
//    }
//
//    @GetMapping("/BService")
//    public String callBService(Authentication authentication) {
//        String username = null;
//
//        if (authentication instanceof JwtAuthenticationToken) {
//            JwtAuthenticationToken jwtAuthToken = (JwtAuthenticationToken) authentication;
//            username = jwtAuthToken.getToken().getClaimAsString("preferred_username"); 
//        } else if (authentication instanceof OAuth2AuthenticationToken) {
//            OAuth2AuthenticationToken oauthToken = (OAuth2AuthenticationToken) authentication;
//            username = oauthToken.getPrincipal().getAttribute("name");
//        } else {
//            return "Unsupported";
//        }
//
//        String response = restTemplate.getForObject("http://localhost:8086/b/call-c", String.class);
//        return "Response from Service B: " + response + ", Username: " + username;
//    }
//}