package com.service1;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.web.client.RestTemplateBuilder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.HttpRequest;
//import org.springframework.http.client.ClientHttpRequestExecution;
//import org.springframework.http.client.ClientHttpRequestInterceptor;
//import org.springframework.http.client.ClientHttpResponse;
//import org.springframework.web.client.RestTemplate;
//import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
//import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
//
//import java.io.IOException;
//import java.util.Collections;
//
//@Configuration
//public class RestTemplateConfig {
//
//    @Autowired
//    private OAuth2AuthorizedClientService authorizedClientService;
//
//    @Bean
//    public RestTemplate restTemplate(RestTemplateBuilder builder) {
//        RestTemplate restTemplate = builder.build();
//
//        // Add an interceptor to include the bearer token in requests
//        restTemplate.setInterceptors(Collections.singletonList(new ClientHttpRequestInterceptor() {
//            @Override
//            public ClientHttpResponse intercept(HttpRequest request, byte[] body,
//                                                ClientHttpRequestExecution execution) throws IOException {
//                // Load the authorized client
//                OAuth2AuthorizedClient authorizedClient = authorizedClientService.loadAuthorizedClient(
//                        "Keycloatjwt", null); // Use your actual client ID here
//
//                // Set the bearer token in the request header
//                request.getHeaders().setBearerAuth(authorizedClient.getAccessToken().getTokenValue());
//
//                // Proceed with the request
//                return execution.execute(request, body);
//            }
//        }));
//
//        return restTemplate;
//    }
//}
