package com.service2;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/b")
public class ServiceBController {
	@GetMapping("hello1")
	public String display1() {
		return "hello service b";
	
}
	 @PostMapping("/receiveMessage")
	public ResponseEntity<String> receiveMessage(@RequestBody String name) {
	    System.out.println("Service B received name: " + name);
	    return new ResponseEntity<>("Service B processed name: " + name, HttpStatus.OK);
	}
	 }
    
   

//
//@GetMapping("/receiveMessage")
//public ResponseEntity<String> receiveName(@RequestParam String name) {
//    System.out.println("Received name: " + name);
//    return ResponseEntity.ok("Received name: " + name);
//}

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.client.RestTemplate;
//
//@RestController
//@RequestMapping("/b")
//public class ServiceBController {
//
//    private final RestTemplate restTemplate;
//
//    @Autowired
//    public ServiceBController(RestTemplate restTemplate) {
//        this.restTemplate = restTemplate;
//    }
//
//    @GetMapping("/call-c")
//    public ResponseEntity<String> callCService(Authentication authentication) {
//        // Get OAuth2 token from the current authentication
//        OAuth2AuthenticationToken oauthToken = (OAuth2AuthenticationToken) authentication;
//        String token = oauthToken.getPrincipal().getAttributes().get("access_token").toString();
//
//        // Set up headers with the token
//        HttpHeaders headers = new HttpHeaders();
//        headers.setBearerAuth(token);
//
//        // Call C Service
//        HttpEntity<String> entity = new HttpEntity<>(headers);
//        ResponseEntity<String> response = restTemplate.exchange(
//                "http://localhost:8082/c/endpoint",  // C Service endpoint
//                HttpMethod.GET,
//                entity,
//                String.class
//        );
//
//        return ResponseEntity.ok(response.getBody());
//    }
//}
