package com.apigateway.keycloak;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.ClaimAccessor;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtDecoders;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	private static final String AUTHORITIES_CLAIM = "groups"; // Modify if Keycloak uses a different claim
	public static final String DLINK_NAME = "Employees"; // Expected group name

	@Bean
	public JwtDecoder jwtDecoder() {
		return JwtDecoders.fromIssuerLocation("http://localhost:8080/realms/Keycloatjwt"); // Replace with your actual
																							// issuer URL
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.authorizeHttpRequests(authorize -> authorize.antMatchers("/api/public").permitAll() // Public path
				.anyRequest().hasAuthority(DLINK_NAME) // Require specific group for all other paths
		).oauth2ResourceServer(oauth2 -> oauth2.jwt().jwtAuthenticationConverter(authConverter()) // Enable custom
																									// converter
		);

		return http.build();
	}

	@Bean
	public JwtAuthenticationConverter authConverter() {
		JwtAuthenticationConverter authConverter = new JwtAuthenticationConverter();
		authConverter.setJwtGrantedAuthoritiesConverter(token -> {
			GrantedAuthority appAuth = getAuthorityFromClaims(token, DLINK_NAME);
			return appAuth == null ? Collections.emptyList() : Arrays.asList(appAuth);
		});

		return authConverter;
	}

	private GrantedAuthority getAuthorityFromClaims(ClaimAccessor token, String appAccessGroup) {
		if (token == null || !token.hasClaim(AUTHORITIES_CLAIM)) {
			return null;
		}

		List<String> groups = token.getClaim(AUTHORITIES_CLAIM);
		return groups != null && groups.contains(appAccessGroup) ? new SimpleGrantedAuthority(appAccessGroup) : null;
	}
}
