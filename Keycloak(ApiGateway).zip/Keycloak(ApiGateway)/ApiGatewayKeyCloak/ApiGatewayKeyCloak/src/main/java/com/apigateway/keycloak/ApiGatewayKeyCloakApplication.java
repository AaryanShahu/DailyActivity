package com.apigateway.keycloak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGatewayKeyCloakApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayKeyCloakApplication.class, args);
	}

}
