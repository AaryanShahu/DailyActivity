package com.apigateway.keycloak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGatewayKeyCloakApplicationTests {

	@Test
	void contextLoads() {
	}

}
